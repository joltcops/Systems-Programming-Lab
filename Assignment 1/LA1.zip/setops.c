#include <stdio.h>
#include <stdlib.h>
#include "setops.h"
#include "settype.h"
void setprint(numset S)
{
    for (int i=1; i<=S[0]; i++)
    {
        if(S[i])
        printf ("%d, ", i);
    }
}
int setsize(numset S)
{
    int c=0;
    for (int i=0; i<S[0]; i++)
    {
        if(S[i])
        c++;
    }
    return c;
}
numset setaddelt(numset S, int i)
{
    if(i>S[0])
    {
        printf ("Error, not in range!\n");
        return S;
    }
    S[i]=1;
    return S;
}
numset setdelet(numset S, int i)
{
    if(i>S[0])
    {
        printf ("Error, not in range!\n");
        return S;
    }
    S[i]=0;
    return S;
}
numset setunion(numset A, numset B)
{
    numset S=setinit(A[0]);
    for (int i=1; i<S[0]; i++)
    {
        S[i]=A[i]||B[i];
    }
    return S;
}
numset setintersection(numset A, numset B)
{
    numset S=setinit(A[0]);
    for (int i=1; i<S[0]; i++)
    {
        S[i]=A[i]&&B[i];
    }
    return S;
}