#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "setops.h"
int howmanypackets(int N)
{
    numset S=setinit(N);
    int count=0;
    while(setsize(S)<N)
    {
        count++;
        int c=(int)rand()%N+1;
        #ifndef STAT_MODE
        printf("Packet %d has coupon %d. Available coupons: {", count, c);
        #endif
        S=setaddelt(S, c);
        #ifndef STAT_MODE
        setprint(S);
        printf("}\n");
        #endif
    }
    return count;
}
int main()
{
    int sum=0;
    double avg;
    int N;
    printf ("Number of coupons(N): ");
    scanf("%d", &N);
    time_t t;
    srand((unsigned) time(&t));
    #ifndef STAT_MODE
    printf ("+++Interactive Mode\n");
    int store=howmanypackets(N);
    printf ("---%d packets were brought\n", store);
    sum+=store;
    #else
    printf("+++Statistics Mode\n");
    for (int i=1; i<1000; i++)
    sum+=howmanypackets(N);
    avg=(double)sum/1000.00;
    printf ("---Average number of packets to buy: %lf\n", avg);
    #endif
    return 0;
}