typedef int* numset;
numset setinit(int N);
numset setrand(int N);
numset setdestroy(numset S);