#include "settype.h"
void setprint(numset S);
int setsize(numset S);
numset setaddelt(numset S, int i);
numset setdelet(numset S, int i);
numset setunion(numset A, numset B);
numset setintersection(numset A, numset B);