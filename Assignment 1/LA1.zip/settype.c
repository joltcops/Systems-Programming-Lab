#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "settype.h"
numset setinit(int N)
{
    numset S;
    S=(numset)malloc((N+1)*sizeof(int));
    S[0]=N;
    for (int i=1; i<=N; i++)
    S[i]=0;
    return S;
}
numset setrand(int N)
{
    numset S;
    S=(numset)malloc((N+1)*sizeof(int));
    S[0]=N;
    time_t t;
    srand((unsigned) time(&t));
    for (int i=1; i<=N; i++)
    {
        S[i]=(int)rand()%2;
    }
    return S;
}
numset setdestroy(numset S)
{
    S[0]=0;
    return S;
}