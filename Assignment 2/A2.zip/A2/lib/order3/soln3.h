#include <stdio.h>
typedef struct struct3
{
    int c1, c2, c3, a0, a1, a2, d;
}recrel3;
int findterm3(int n, recrel3 r);