#include <stdio.h>
typedef struct struct1
{
    int d, c1, a0;
}recrel1;
int findterm1(int n, recrel1 r);