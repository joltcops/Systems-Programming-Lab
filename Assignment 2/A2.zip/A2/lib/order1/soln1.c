#include "soln1.h"
int findterm1(int n, recrel1 r)
{
    int r1=r.a0;
    int res;
    for (int i=0; i<n; i++)
    {
        res=r1*r.c1+r.d;
        r1=res;
    }
    return res;
}