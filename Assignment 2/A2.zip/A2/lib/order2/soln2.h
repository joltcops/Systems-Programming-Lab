#include <stdio.h>
typedef struct struct2
{
    int c1, c2, a0, a1, d;
}recrel2;
int findterm2(int n, recrel2 r);